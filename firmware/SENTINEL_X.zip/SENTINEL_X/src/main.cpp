#include <Arduino.h>
#include <MQUnifiedsensor.h>

#include "network/WiFiManager.h"
#include "network/MQTTManager.h"
#include "interface/BUZZER.h"
#include "interface/OLED.h"
#include "sensors/MQ2.h"
#include "sensors/DHT22.h"
#include "sensors/PIR.h"
#include <ArduinoJson.h>

#define PIN_MQ2 A0
#define PIN_DHT D5
#define PIN_BUZZER D6
#define PIN_PIR D7
#define PIN_SCL D3
#define PIN_SDA D2
#define LED_RED D1
#define LED_GREEN D0

#define TOPIC_PREFIX "sentinel/v1"

OLED ecran(PIN_SCL,PIN_SDA,64,128);
BUZZER buzzer(PIN_BUZZER,ecran,LED_RED,LED_GREEN);

MQ2 mq2(PIN_MQ2);
DHT22 dht(PIN_DHT);
PIR pir(PIN_PIR);

const char* WIFI_SSID = "Seezix";
const char* WIFI_PASS = "2TR-LD#zB@GmEh$G-zebi";
WifiManager wifi(WIFI_SSID, WIFI_PASS);

const char* MQTT_HOST = "192.168.137.158";
const int   MQTT_PORT = 8883;
const char* MQTT_USER = "esp";
const char* MQTT_PASS = "t8lfKdRBoKldzk09SaCk";
const char* DEVICE    = "SX-001";
static const char CA_CERT[] PROGMEM = R"EOF(
-----BEGIN CERTIFICATE-----
MIIFiTCCA3GgAwIBAgIUUMWOcwzGL0Toxt93n0oMEI+4EBUwDQYJKoZIhvcNAQEL
BQAwVDELMAkGA1UEBhMCRlIxEjAQBgNVBAgMCU9jY2l0YW5pZTETMBEGA1UECgwK
U2VudGluZWwtWDEcMBoGA1UEAwwTU2VudGluZWwtWCBMb2NhbCBDQTAeFw0yNjEw
MDYxMzQ5NTFaFw0zNjEwMDMxMzQ5NTFaMFQxCzAJBgNVBAYTAkZSMRIwEAYDVQQI
DAlPY2NpdGFuaWUxEzARBgNVBAoMClNlbnRpbmVsLVgxHDAaBgNVBAMME1NlbnRp
bmVsLVggTG9jYWwgQ0EwggIiMA0GCSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQCU
JtokhOWgzF7JqwQmALXoghKoTGVv7yp9WLIoo6bsg6TL+u28Gs7v4S7Ta+M5TFEy
aaSFztrVxZG6EFFAOR6y/kROWQu94YMr2m1yO0ZEHDQQ0e3C4ht04A7IVpT/uFAD
aPcNGvM2S1ifoxrZp3N4syDLnoc4DY6m0eeWQyGky3SuL+PwOjJxZbERIxu+hnZb
fy4qYwpCqAxe6cuoMOKpp9A6G/7PX+9UpppObDhkx8TZhzksMb+OH5nWU9OHeXzh
BoBFWeKVdEXZlp6N0dnNx8/EGGfN1lhY+bcX+9Zcb7a1c6BYYKDE00B2KhmY2+03
gfdFSALLWo2/LFJf+CBsshDo9k4Kf7KztWXeCsn/heC/c8tog6ot+/ygQgiqCvjf
hRJatp/MHezDi5aq2zxfXiCj3Cf93VA1aTev+sPUxSphcP9ezi3dcrmxpMEZHO1X
POOV0k2fgg0OQjcqxJZ0CKCqy5XkOLB0vq9adO1D5L1pLLJqmeLXhFUs1foMqZ2k
BXLJNPcM+2lvFTJZrkpvCKlCYM8751Ogivhsq+DBBlJz1lVI1ZIo4GgEm/5lxHcU
aJ3tTYLIFj337ph4Hzwj9Oy4/Syui/79Xkk3IF9GRWHs2zkjp8Cm8ZYal2xSiTf7
nJ6LrH0UjUETdAdfi9BVoakdxT7XoWmBHFwgAny3zQIDAQABo1MwUTAdBgNVHQ4E
FgQUCqWxs6Mvnujnn//lkJWUka6L28MwHwYDVR0jBBgwFoAUCqWxs6Mvnujnn//l
kJWUka6L28MwDwYDVR0TAQH/BAUwAwEB/zANBgkqhkiG9w0BAQsFAAOCAgEAUK/i
ydkwX7uFf5Kke5Gi4niPy5xDiK6dXCSAfBKkuQPiJaPS5eJ2pp2u1J4t0c7zRs8E
rXiTU+XD4sHK/SXmB6SQW+/VKsP4YG7nJxFdXR5Wykt6vh+2sdr1LFlg7PafJOfV
nUjqXplaKHU0Lo+IiyqCy0zH0HOrKgIuxuUoyaX24GQ2ZPcgp58+dN+XLyS5CqyO
8QnWf522tNyn+FUf9B4qiQbZUR00ByTu0fJGtqJDLZ5xpe1aoKU4o7861PGOUK50
GJrO/AvRCfiTyran1lqJqfL6NHxlr+OicmyY2lbVPsQNI2NVrc7qfhGCmeBPvS5Q
PFQoKDIZY3pXgJq3ZzuXOomMlM4iUSjbwv9oBF0RhMr9QP5QV3ZN6e9fMtxUc/JH
arzGP7c1sFKzrbe7jLFDG4kAvbC34alq53xW2WSUwSU4shi5KwZVsxGa7eFd2M18
OUahB0V7PB9W5ROj8yixEA1iP97ABBlGQeqRHAvSNBvOKqBlBouw9i+ey0lYi95d
iSp+aRoNvXLpAM5ENi3UKvYnBHBaf++7pgiyxIkCoTHcXfAp4C0KPIZAXgFV6krz
x3DWO+z2gZk2kWOcPhKdF4wKZsfV3of9BdH8YLq20C+Pv8B2z4yCOAkc59LBkiQj
1oiXY5fqUdDJHCejCbnqrYuFKl1p+QjhScShW9M=
-----END CERTIFICATE-----
)EOF";
MQTTManager mqtt(MQTT_HOST,MQTT_PORT,MQTT_USER,MQTT_PASS,DEVICE,buzzer);

String tStatus, tTelemetry, tCmd, tReply;
unsigned long lastSend = 0;

static unsigned long seq = 0;

// Remplit {avg,min,max,last}. Sans historique, les quatre valent la mesure courante.
void setStat(JsonDocument& doc, const char* key, float v) {
    if (isnan(v)) return;               // capteur muet : on omet le champ
    JsonObject o = doc[key].to<JsonObject>();
    o["avg"] = v; o["min"] = v; o["max"] = v; o["last"] = v;
}

void setup() {

    Serial.begin(115200);

    ecran.afficherTexte("========================");
    Serial.println("        BOOT ESP");
    Serial.println("========================");

    buzzer.begin();
    ecran.begin();

    wifi.begin();
    //----Synchro Heure pour TLS-----
    configTime(0, 0, "pool.ntp.org", "time.nist.gov");
    Serial.print("Synchro heure");
    time_t now = time(nullptr);
    while (now < 8 * 3600 * 2) {   // attend une date plausible (> 1970)
        delay(500);
        Serial.print(".");
        now = time(nullptr);
    }
    Serial.println(" OK");
    //-----fin synchro-----
    mqtt.setCACert(CA_CERT);
    mqtt.begin();

    mq2.begin();
    dht.begin();
    pir.begin();

    tStatus    = String(TOPIC_PREFIX) + "/" + DEVICE + "/status";
    tTelemetry = String(TOPIC_PREFIX) + "/" + DEVICE + "/telemetry";
    tCmd       = String(TOPIC_PREFIX) + "/" + DEVICE + "/cmd";
    tReply     = String(TOPIC_PREFIX) + "/" + DEVICE + "/cmd/ack";
}

static unsigned int pirActiveCount = 0;
static unsigned int pirSampleCount = 0;

void loop() {
// write your code here

    wifi.update();
    dht.update();

    int gas = mq2.readRaw();

    float temperature = dht.getTemperature();
    float humidity = dht.getHumidity();

    int proximity = pir.read();

    pirSampleCount++;

    if (proximity == 1) {
        pirActiveCount++;
    }

    if (millis() - lastSend > 5000) {

        //buzzer.beep(500);

        JsonDocument doc;

        float pirAverage = 0.0;

        if (pirSampleCount > 0) {
            pirAverage =
                (float) pirActiveCount / pirSampleCount;
        }

        pirActiveCount = 0;
        pirSampleCount = 0;

        Serial.println("PIR average = " + String(pirAverage));

        doc["seq"]        = seq++;
        doc["uptime_ms"]  = millis();
        doc["interval_s"] = 5;    // obligatoire côté backend
        doc["samples"]    = 1;    // obligatoire côté backend

        setStat(doc, "gas_raw",       gas);
        setStat(doc, "temperature_c", temperature);
        setStat(doc, "humidity_pct",  humidity);
        setStat(doc, "motion_count",  round(pirAverage));

        doc["ir_count"]     = 0;

        char jsonBuffer[384];
        serializeJson(doc, jsonBuffer);

        mqtt.publish(tTelemetry.c_str(), jsonBuffer);
        lastSend = millis();

        if (temperature > 27) {
            buzzer.beep(500);
        }
    }

    delay(200);
}