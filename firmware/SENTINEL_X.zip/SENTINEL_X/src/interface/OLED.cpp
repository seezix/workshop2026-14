//
// Created by yann5 on 07/10/2026.
//

#include "OLED.h"

OLED::OLED(
    uint8_t pinScl,
    uint8_t pinSda,
    const int Height,
    const int Width
) : _pinScl(pinScl),_pinSda(pinSda),_height(Height),_width(Width),_ecran(Width, Height, &Wire, -1) {
}


void OLED::begin() {

    Wire.begin(_pinSda, _pinScl);

    bool result = _ecran.begin(SSD1306_SWITCHCAPVCC, 0x3C);

    if (!result) {
        Serial.println("OLED BEGIN ECHEC");
        return;
    }

    _ecran.clearDisplay();

    _ecran.setTextSize(1);
    _ecran.setTextColor(SSD1306_WHITE);
    _ecran.setCursor(0, 0);

    _ecran.println("OLED OK");

    _ecran.display();

    Serial.println("OLED OK");
}

void OLED::afficherTexte(const char* texte) {

    _ecran.clearDisplay();

    _ecran.setTextSize(1);

    _ecran.setTextColor(SSD1306_WHITE);

    _ecran.setCursor(0, 0);

    _ecran.println(texte);

    _ecran.display();
}

void OLED::afficherCroix() {
    _ecran.clearDisplay();

    _ecran.drawLine(
        20, 10,
        108, 54,
        SSD1306_WHITE
    );

    _ecran.drawLine(
        108, 10,
        20, 54,
        SSD1306_WHITE
    );

    _ecran.display();
}