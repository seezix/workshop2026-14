//
// Created by yann5 on 07/10/2026.
//

#include "BUZZER.h"

#include <Arduino.h>

BUZZER::BUZZER(uint8_t pin, OLED& ecran, uint8_t redPin, uint8_t greenPin):
    _pin(pin),_state(false),_ecran(ecran),_redPin(redPin),_greenPin(greenPin) {
}

void BUZZER::begin() {
    pinMode(_pin, OUTPUT);
    pinMode(_redPin, OUTPUT);
    pinMode(_greenPin, OUTPUT);
    off();
}

void BUZZER::updateLed(bool active)
{
    if (active) {
        // Buzzer actif → rouge
        digitalWrite(_redPin, HIGH);
        digitalWrite(_greenPin, LOW);
    } else {
        // Buzzer inactif → vert
        digitalWrite(_redPin, LOW);
        digitalWrite(_greenPin, HIGH);
    }
}

void BUZZER::on() {

    digitalWrite(_pin, HIGH);
    updateLed(true);
    _ecran.afficherCroix();

    _state = true;
}

void BUZZER::off() {

    digitalWrite(_pin, LOW);
    updateLed(false);

    _state = false;
}

void BUZZER::beep(unsigned long duration)
{
    on();
    delay(duration);
    off();
}

bool BUZZER::isOn() const {
    return _state;
}
