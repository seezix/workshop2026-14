//
// Created by yann5 on 07/10/2026.
//

#ifndef PIO_OLED_H
#define PIO_OLED_H

#include <Adafruit_SSD1306.h>

class OLED {
public:
    explicit OLED(
        uint8_t pinScl,
        uint8_t pinSda,
        int Height,
        int Width
    );

    void begin();

    void afficherTexte(const char* texte);
    void afficherCroix();
private:
    uint8_t _pinScl;
    uint8_t _pinSda;
    const int _height;
    const int _width;

    Adafruit_SSD1306 _ecran;
};


#endif //PIO_OLED_H
