//
// Created by yann5 on 07/10/2026.
//

#ifndef PIO_BUZZER_H
#define PIO_BUZZER_H
#include <cstdint>
#include "OLED.h"

class BUZZER {
public:
    explicit BUZZER(uint8_t pin,OLED& ecran, uint8_t redPin, uint8_t greenPin);

    void begin();

    void on();
    void off();

    void beep(unsigned long duration);

    [[nodiscard]] bool isOn() const;

private:
    uint8_t _pin;
    bool _state;
    OLED& _ecran;
    uint8_t _redPin;
    uint8_t _greenPin;

    void updateLed(bool active);
};


#endif //PIO_BUZZER_H
