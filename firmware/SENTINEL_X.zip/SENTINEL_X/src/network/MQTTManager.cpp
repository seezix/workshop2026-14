//
// Created by yann5 on 06/10/2026.
//

#include "MQTTManager.h"
#include <ctime>
#include <ArduinoJson.h>
#include "../interface/BUZZER.h"

#define TOPIC_PREFIX "sentinel/v1"

MQTTManager::MQTTManager(
    const char* server,
    uint16_t port,
    const char* user,
    const char* password,
    const char* clientId,
    BUZZER& buzzer
)
    : _server(server),
      _port(port),
      _user(user),
      _password(password),
      _clientId(clientId),
      _buzzer(buzzer),
      _mqttClient(_wifiClient) {
}

void MQTTManager::setCACert(const char* caCert) {
    _caCert = caCert;
}

void MQTTManager::begin() {

    if (_caCert != nullptr) {
        _wifiClient.setTrustAnchors(new BearSSL::X509List(_caCert));
    } else {
        Serial.println("[MQTT] ATTENTION : aucun certificat CA fourni !");
    }

    _mqttClient.setServer(_server, _port);

    _mqttClient.setCallback(
        [this](char* topic, byte* payload, unsigned int len) {
            this->onMessage(topic, payload, len);
        }
    );

    _mqttClient.setBufferSize(512);

    connect();
}

void MQTTManager::onMessage(char* topic, byte* payload, unsigned int len) {
    Serial.printf("MQTT reçu [%s] (%u o)\n", topic, len);

    String cmd;

    for (unsigned int i = 0; i < len; i++) {
        cmd += (char)payload[i];
    }

    cmd.trim();

    String tReply = String(topic);
    const char *reply = "Success";

    if (_tConfig == topic) { onConfig(payload, len); return; }

    if (_tCmd == topic) {
        if (strcmp(topic, "buzzer") == 0) {

            if (cmd == "continue") {
                if (_buzzer.isOn()) {
                    _buzzer.off();
                } else {
                    _buzzer.on();
                }
            } else if (cmd == "unique") {
                _buzzer.on();
                delay(1000);
                _buzzer.off();
            } else if (cmd == "stop") {
                _buzzer.off();
            } else if (cmd == "rythme") {
                for (unsigned int i = 0; i < 10; i++) {
                    if (_buzzer.isOn()) {
                        _buzzer.off();
                    } else {
                        _buzzer.on();
                    }
                    delay(1000);
                }
                _buzzer.off();
            } else {
                _buzzer.off();
                reply = "Echec (buzzer éteint)";
                Serial.println("Commande buzzer inconnue (buzzer éteint)");
            }
            _mqttClient.publish(
                tReply.c_str(),
                reply
            );
        }
    }
}

void MQTTManager::onConfig(const byte* payload, unsigned int len) {
    JsonDocument doc;
    if (deserializeJson(doc, payload, len)) return;
    if (doc["interval_s"].is<int>()) _intervalS = doc["interval_s"];
    if (doc["armed"].is<bool>())     _armed     = doc["armed"];
    Serial.printf("Config : interval=%us armed=%d\n", _intervalS, _armed);
}

/*void MQTTManager::onMessage(char* topic,byte* payload,unsigned int len) {

    String cmd;

    for (unsigned int i = 0; i < len; i++) {
        cmd += (char)payload[i];
    }

    cmd.trim();

    Serial.print("Commande MQTT reçue : ");
    Serial.println(cmd);

    String tReply = String(topic);
    const char *reply = "Success";

    if (strcmp(topic, "buzzer") == 0) {

        if (cmd == "continue") {
            if (_buzzer.isOn()) {
                _buzzer.off();
            } else {
                _buzzer.on();
            }
        } else if (cmd == "unique") {
            _buzzer.on();
            delay(1000);
            _buzzer.off();
        } else if (cmd == "stop") {
            _buzzer.off();
        } else if (cmd == "rythme") {
            for (unsigned int i = 0; i < 10; i++) {
                if (_buzzer.isOn()) {
                    _buzzer.off();
                } else {
                    _buzzer.on();
                }
                delay(1000);
            }
            _buzzer.off();
        } else {
            _buzzer.off();
            reply = "Echec (buzzer éteint)";
            Serial.println("Commande buzzer inconnue (buzzer éteint)");
        }
        _mqttClient.publish(
            tReply.c_str(),
            reply
        );
    }

    else if (cmd == "status") {

        _mqttClient.publish(
            tReply.c_str(),
            "status OK"
        );

    } else if (cmd == "reboot") {

        _mqttClient.publish(
            tReply.c_str(),
            "reboot..."
        );

        delay(200);

        EspClass::restart();

    } else {

        _mqttClient.publish(
            tReply.c_str(),
            "commande inconnue"
        );
    }
}*/

void MQTTManager::connect() {

    if (!WiFi.isConnected()) {
        return;
    }

    String base = String(TOPIC_PREFIX) + "/" + _clientId;
    _tStatus = base + "/status";
    _tConfig = base + "/config";
    _tCmd    = base + "/cmd";
    _tAck    = base + "/cmd/ack";

    Serial.print("Connexion MQTT... ");

    if (_mqttClient.connect(_clientId, _user, _password,
                            _tStatus.c_str(), 1, true,
                            R"({"state":"offline"})")) {
        Serial.println("OK");
        _mqttClient.publish(_tStatus.c_str(),
                            R"({"state":"online","fw":"1.0.0"})", true);
        _mqttClient.subscribe(_tConfig.c_str(), 1);
        _mqttClient.subscribe(_tCmd.c_str(), 1);
                            }  else {
        Serial.print("Échec MQTT, code = ");
        Serial.println(_mqttClient.state());

        char err[128];
        int e = _wifiClient.getLastSSLError(err, sizeof(err));
        if (e != 0) {
            Serial.print("Erreur TLS : ");
            Serial.println(err);
        }
    }
}

void MQTTManager::update() {

    if (!WiFi.isConnected()) {
        return;
    }

    if (!_mqttClient.connected()) {
        connect();
    } else {
        _mqttClient.loop();
    }
}

bool MQTTManager::isConnected() {
    return _mqttClient.connected();
}

bool MQTTManager::publish(
    const char* topic,
    const char* payload
) {
    if (!isConnected()) {
        return false;
    }

    return _mqttClient.publish(topic, payload);
}