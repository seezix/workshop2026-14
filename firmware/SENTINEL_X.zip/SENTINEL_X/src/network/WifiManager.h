//
// Created by yann5 on 06/10/2026.
//

#ifndef PIO_WIFIMANAGER_H
#define PIO_WIFIMANAGER_H

#include <Arduino.h>

class WifiManager {

public:

    WifiManager(const char* ssid, const char* password);

    void begin();
    void update();

    bool isConnected();

    String getIP();

private:

    const char* _ssid;
    const char* _password;

    void connect();
};


#endif //PIO_WIFIMANAGER_H
