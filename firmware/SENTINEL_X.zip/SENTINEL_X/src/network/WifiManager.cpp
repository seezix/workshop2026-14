//
// Created by yann5 on 06/10/2026.
//

#include "WifiManager.h"

#include <ESP8266WiFi.h>


WifiManager::WifiManager(const char* ssid,const char* password)
    : _ssid(ssid),_password(password) {
}


void WifiManager::begin() {

    WiFi.mode(WIFI_STA);

    connect();
}


void WifiManager::connect() {

    Serial.print("Connexion au WiFi : ");
    Serial.println(_ssid);

    WiFi.begin(_ssid, _password);

    unsigned long start = millis();

    while (
        WiFi.status() != WL_CONNECTED &&
        millis() - start < 15000
    ) {

        delay(500);

        Serial.print(".");
    }

    Serial.println();

    if (isConnected()) {

        Serial.println("WiFi connecté");

        Serial.print("IP : ");
        Serial.println(WiFi.localIP());

    } else {

        Serial.println("Échec de connexion WiFi");
    }
}


void WifiManager::update() {

    if (!isConnected()) {

        Serial.println("WiFi déconnecté");

        connect();
    }
}


bool WifiManager::isConnected() {

    return WiFi.status() == WL_CONNECTED;
}


String WifiManager::getIP() {

    if (!isConnected()) {
        return "";
    }

    return WiFi.localIP().toString();
}