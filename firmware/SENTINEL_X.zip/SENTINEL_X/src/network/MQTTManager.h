//
// Created by yann5 on 06/10/2026.
//

#ifndef PIO_MQTTMANAGER_H
#define PIO_MQTTMANAGER_H

#include <Arduino.h>
#include <ESP8266WiFi.h>
#include <WiFiClientSecure.h>
#include <PubSubClient.h>
#include <interface/BUZZER.h>

class MQTTManager {
public:
    MQTTManager(
        const char* server,
        uint16_t port,
        const char* user,
        const char* password,
        const char* clientId,
        BUZZER& buzzer
        );

    void begin();
    void update();

    bool isConnected();
    bool publish(const char* topic, const char* payload);

    void setCACert(const char* caCert);

    [[nodiscard]] uint16_t intervalS() const { return _intervalS; }
    [[nodiscard]] bool armed() const { return _armed; }

private:
    const char* _server;
    uint16_t _port;
    const char* _user;
    const char* _password;
    const char* _clientId;
    const char* _caCert = nullptr;
    String _tStatus, _tConfig, _tCmd, _tAck;
    uint16_t _intervalS = 5;
    bool _armed = true;
    void onConfig(const byte* payload, unsigned int len);

    BUZZER& _buzzer;

    WiFiClientSecure _wifiClient;
    PubSubClient _mqttClient;

    void connect();
    void onMessage(char* topic, byte* payload, unsigned int len);
};

#endif
